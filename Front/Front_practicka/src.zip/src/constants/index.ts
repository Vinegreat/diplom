export const DEFAULT_NAME = 'Umi Max';
