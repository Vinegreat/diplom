
import { trim } from '@/utils/format';
import { PageContainer } from '@ant-design/pro-components';
import { useModel } from '@umijs/max';
import styles from './index.less';

const HomePage: React.FC = () => {
  return (
    <PageContainer ghost>

    </PageContainer>
  );
};

export default HomePage;

